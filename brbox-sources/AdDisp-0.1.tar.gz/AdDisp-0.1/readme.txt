OLED display control library wrapper which is originally from Adafruit.
As of now, this library is specifically written for raspberry pi hardware.
see the original sources at https://github.com/hallard/ArduiPi_OLED

